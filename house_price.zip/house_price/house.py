import tkinter as tk
from tkinter import ttk
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np

# Sample data for demonstration purposes
# Replace this with your actual dataset for real use.
# The input features (X) are house size, number of bedrooms, and age of the house.
# The target variable (y) is the corresponding house price.

df=pd.read_csv("Housing.csv")


X = df.iloc[:,1:4].to_numpy()
y = df.iloc[:,0:1].to_numpy().flatten()

print(X)
print(y)

# Train the regression model
model = LinearRegression()
model.fit(X, y)

# Create the GUI
def predict_price():
    features_str = [
        entry_house_size.get(),
        entry_bedrooms.get(),
        entry_age.get(),
    ]
    try:
        features = [float(f) for f in features_str]
        if any(f <= 0 for f in features):
            raise ValueError("All input values must be positive numbers.")

        predicted_price = model.predict([features])
        label_result.config(text=f"Predicted Price: Rs {predicted_price[0]:,.2f}")
    except ValueError as e:
        label_result.config(text=str(e))
    except Exception as e:
        label_result.config(text="An error occurred. Please try again later.")

def reset_fields():
    entry_house_size.delete(0, tk.END)
    entry_bedrooms.delete(0, tk.END)
    entry_age.delete(0, tk.END)
    label_result.config(text="")

root = tk.Tk()
root.title("House Price Prediction")
root.geometry("400x400")

frame = ttk.Frame(root, padding="20")
frame.grid(row=0, column=0)

# House Size
label_house_size = ttk.Label(root, text="House Size (sqft):")
label_house_size.place(relx=0.1,rely=0.1,relwidth=0.3,relheight=0.1)
entry_house_size = ttk.Entry(root)
entry_house_size.place(relx=0.45,rely=0.1,relwidth=0.35,relheight=0.1)
entry_house_size.focus()

# Number of Bedrooms
label_bedrooms = ttk.Label(root, text="Number of Bedrooms:")
label_bedrooms.place(relx=0.1,rely=0.21,relwidth=0.3,relheight=0.1)
entry_bedrooms = ttk.Entry(root)
entry_bedrooms.place(relx=0.45,rely=0.21,relwidth=0.35,relheight=0.1)

# Age of the House
label_age = ttk.Label(root, text="Age of the House (years):")
label_age.place(relx=0.1,rely=0.32,relwidth=0.3,relheight=0.1)
entry_age = ttk.Entry(root)
entry_age.place(relx=0.45,rely=0.32,relwidth=0.35,relheight=0.1)

# Predict and Reset Buttons
btn_predict = ttk.Button(root, text="Predict Price", command=predict_price)
btn_predict.place(relx=0.1,rely=0.43,relwidth=0.65,relheight=0.1)
btn_reset = ttk.Button(root, text="Reset", command=reset_fields)
btn_reset.place(relx=0.1,rely=0.55,relwidth=0.65,relheight=0.1)

# Prediction Result
label_result = ttk.Label(root, text="")
label_result.place(relx=0.1,rely=0.65,relwidth=0.65,relheight=0.1)

root.mainloop()
